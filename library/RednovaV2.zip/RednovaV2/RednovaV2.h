#ifndef RednovaV2_h // tan?mlay?c? kutuphane ismimiz Rednova
#define RednovaV2_h

    
//dip switch i?in mode ad?nda return fonk tan?mla
class RednovaV2Class{ //ss isminde class olu?turuyoruz
  public: // heryerden eri?ilebilir olmas? i?in public
    RednovaV2Class(); //Class isminde fonksiyon olu?turuyoruz
    void SETUP(); //setup isminde fonksiyon olu?turuyoruz
    void Forward(byte speed, int time);
    void Backward(byte speed, int time);
    void TurnRight(byte speed, int time);
    void TurnLeft(byte speed, int time);
void DualDirection(float Lval, float Rval, int Time);    
    void MixLed(int Time);
    byte mode();
        void Blue(int Time);
 void Red(int Time);
 void Green(int Time);
        void Purple(int Time);
 void Yellow(int Time);
 void White(int Time);
 void LightBlue(int Time);
void Buzzer(boolean x , int Time );
void StartRednovaV2(boolean x);

void RGB(boolean x , boolean y , boolean z , int Time );

};


extern RednovaV2Class RednovaV2;

#endif
