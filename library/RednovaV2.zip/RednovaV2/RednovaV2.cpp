#include "Arduino.h"
#include "RednovaV2.h"
#define M2_Pwm1 9
#define M2_Pwm2 10
#define M1_Pwm1 11
#define M1_Pwm2 5
#define UL1 0 //Twice Led
#define UL2 1 //Single Led
#define UL3 30 //RX Led
#define BZR 8
String RednovaV2ReadString; 
//
//byte speed;
RednovaV2Class::RednovaV2Class(){
  pinMode(BZR ,OUTPUT);
  pinMode(M1_Pwm1, OUTPUT);
  pinMode(M1_Pwm2, OUTPUT);
  pinMode(M2_Pwm1, OUTPUT);
  pinMode(M2_Pwm2, OUTPUT);
  pinMode(UL1, OUTPUT);
  pinMode(UL2, OUTPUT);
  pinMode(UL3, OUTPUT);
digitalWrite(13,HIGH);
digitalWrite(14,HIGH);
digitalWrite(15,HIGH);
digitalWrite(16,HIGH);
}

void RednovaV2Class::SETUP(){

}
  



void RednovaV2Class::RGB(boolean x , boolean y , boolean z , int Time ){
int R;
int G;
int B;
if( x == 1){
R =0;
}else{
R=1;
}
if( y == 1){
 G = 0;
}else{
G = 1;
}
if( z == 1){
B = 0;
}else{
B = 1;
}
 digitalWrite(UL1,R);
 digitalWrite(UL2,B);
 digitalWrite(UL3,G);
    delay(Time);
}
void RednovaV2Class::Buzzer(boolean x , int Time ){
  if (x == 1) {
    int r = Time/2  ;
    for (int i = 0; i <= r; i++) {
      digitalWrite(BZR, HIGH);
      delay(1);
      digitalWrite(BZR, LOW);
      delay(1);
    }
  } else if (x == 0) {
    digitalWrite(BZR, LOW);
    delay(Time);
  }

}
void RednovaV2Class::Red(int Time ){

 digitalWrite(UL1,LOW);
 digitalWrite(UL2,HIGH);
 digitalWrite(UL3,HIGH);
delay(Time);

}
void RednovaV2Class::Blue(int Time ){

 digitalWrite(UL2,LOW);
 digitalWrite(UL1,HIGH);
 digitalWrite(UL3,HIGH);
delay(Time);

}
void RednovaV2Class::Green(int Time ){

 digitalWrite(UL3,LOW);
 digitalWrite(UL2,HIGH);
 digitalWrite(UL1,HIGH);
delay(Time);

}
void RednovaV2Class::LightBlue(int Time ){

 digitalWrite(UL1,HIGH);
 digitalWrite(UL2,LOW);
 digitalWrite(UL3,LOW);
delay(Time);

}
void RednovaV2Class::Purple(int Time ){

 digitalWrite(UL2,LOW);
 digitalWrite(UL1,LOW);
 digitalWrite(UL3,HIGH);
delay(Time);

}
void RednovaV2Class::Yellow(int Time ){

 digitalWrite(UL3,LOW);
 digitalWrite(UL2,HIGH);
 digitalWrite(UL1,LOW);
delay(Time);

}
void RednovaV2Class::White(int Time ){

 digitalWrite(UL3,LOW);
 digitalWrite(UL2,LOW);
 digitalWrite(UL1,LOW);
delay(Time);

}
void Forward(byte speed, int time);
void RednovaV2Class::Forward(byte speed, int Time){
   
   speed = constrain(speed,0,100);
speed = map(speed,0,100,0,255);
   digitalWrite(M1_Pwm2,LOW);
   digitalWrite(M2_Pwm1,LOW);
   analogWrite(M1_Pwm1, speed);
   analogWrite(M2_Pwm2, speed);
   delay(Time);
   
}
 void Backward(byte speed, int time);
void RednovaV2Class::Backward(byte speed, int Time){
   
   speed = constrain(speed,0,100);
  speed = map(speed,0,100,0,255);
   digitalWrite(M1_Pwm1,LOW);
  digitalWrite(M2_Pwm2,LOW);
   analogWrite(M1_Pwm2, speed);
   analogWrite(M2_Pwm1, speed);
   delay(Time);
   
}

void TurnRight(byte speed, int time);

void RednovaV2Class::TurnRight(byte speed, int Time){
   
   speed = constrain(speed,0,100);
   speed = map(speed,0,100,0,255);
  digitalWrite(M1_Pwm2,LOW);
   digitalWrite(M2_Pwm2,LOW);
   analogWrite(M1_Pwm1, speed);
   analogWrite(M2_Pwm1, speed);
   delay(Time);
   
   
}
void TurnLeft(byte speed, int time);
void RednovaV2Class::TurnLeft(byte speed, int Time){
   
   speed = constrain(speed,0,100);
   speed = map(speed,0,100,0,255);
   digitalWrite(M1_Pwm1,LOW);
   digitalWrite(M2_Pwm1,LOW);
   analogWrite(M1_Pwm2, speed);
   analogWrite(M2_Pwm2, speed);
   delay(Time);
   
   
}void RednovaV2Class::DualDirection(float Lval, float Rval, int Time){

  Lval= Lval * 2.55;
  Rval = Rval * 2.55;
  if (Lval > 0) {
   digitalWrite(M1_Pwm2,LOW);
    analogWrite(M1_Pwm1, Lval);
  } else {
    Lval = abs(Lval);
   digitalWrite(M1_Pwm1,LOW);
    analogWrite(M1_Pwm2, Lval);
  }
  if (Rval > 0) {
   digitalWrite(M2_Pwm1,LOW);
    analogWrite(M2_Pwm2, Rval);
  } else {
    Rval = abs(Rval);
   digitalWrite(M2_Pwm2,LOW);
    analogWrite(M2_Pwm1, Rval);
  }
  delay(Time);
if(Lval==0){

 analogWrite(M1_Pwm1,255);
    analogWrite(M1_Pwm2, 255);

}
if(Rval==0){

 analogWrite(M2_Pwm1,255);
    analogWrite(M2_Pwm2, 255);

}
  
}

void RednovaV2Class::MixLed(int Time){

for (int i=0; i <= Time; i++){
 digitalWrite(UL1,LOW);
 digitalWrite(UL2,HIGH);
 digitalWrite(UL3,HIGH);
delay(50);
 digitalWrite(UL1,LOW);
 digitalWrite(UL2,LOW);
 digitalWrite(UL3,HIGH);
delay(50);
 digitalWrite(UL1,HIGH);
 digitalWrite(UL2,LOW);
 digitalWrite(UL3,HIGH);
delay(50);
 digitalWrite(UL1,HIGH);
 digitalWrite(UL2,LOW);
 digitalWrite(UL3,LOW);
delay(50);
 digitalWrite(UL1,HIGH);
 digitalWrite(UL2,HIGH);
 digitalWrite(UL3,LOW);
delay(50);
 digitalWrite(UL1,LOW);
 digitalWrite(UL2,HIGH);
 digitalWrite(UL3,LOW);
delay(50);
}
 digitalWrite(UL1,HIGH);
 digitalWrite(UL2,HIGH);
 digitalWrite(UL3,HIGH);
}

void RednovaV2Class::StartRednovaV2(boolean x){
if(x == 1){
    RednovaV2.Buzzer(1,250);
    RednovaV2.Buzzer(0,10);
 RednovaV2.Buzzer(1,250);
    RednovaV2.MixLed(1); 
  RednovaV2.Buzzer(1,350);
  RednovaV2.MixLed(3);
}else{
    RednovaV2.Buzzer(0,10);
}

}

RednovaV2Class RednovaV2 = RednovaV2Class();